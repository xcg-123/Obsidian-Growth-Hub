# ToBeGreat Starter

ToBeGreat（TBG）是一个以 Markdown 保存记录的 Obsidian 工作空间。你可以用六个模块管理目标、知识、学业、日程、日记和科研项目。TBG Home 提供工作台，TBG 日记主题汇编把带标签的日记段落汇编成主题页。

## 安装与打开

1. 安装 **Obsidian 1.8.7 或更新版本**。Windows 下载官方安装程序。Ubuntu 可选官方 Deb 或 AppImage。Android 可从 Google Play 安装或使用官方 APK。[官方下载](https://obsidian.md/download)
2. 完整解压 ZIP。在 Obsidian 的仓库管理器选择**打开文件夹作为仓库**，选中同时含 `README.md` 与 `.obsidian/` 的内层 Starter 文件夹。
3. 打开**设置 → 第三方插件**，阅读提示并自行确认允许第三方插件，然后启用 **TBG Home** 和 **TBG 日记主题汇编**。两者已随包放在 `.obsidian/plugins/`。
4. 在命令面板运行 **TBG Home: 打开首页**。桌面也可点击左侧房屋图标。希望下次自动打开时，可在 TBG Home 设置启用“启动时打开首页”。

## 从一个模块开始

| 模块 | 第一次可以做什么 |
| --- | --- |
| [个人成长与生活管理](01-个人成长与生活管理/README.md) | 新建一个成长目标，写下下一步。 |
| [第二大脑](02-第二大脑/README.md) | 写一条知识笔记，或用课程模板建立第一门课程。 |
| [学业与升学规划](03-学业与升学规划/README.md) | 新建学业目标、事实记录或升学决策。 |
| [学习与时间管理](04-学习与时间管理/README.md) | 在时间台新建安排，点卡片继续编辑。 |
| [日记与随笔](05-日记与随笔/README.md) | 写今日日记，给一段正文加标签。 |
| [科研与项目实践](06-科研与项目实践/README.md) | 建立论文主记录或项目主记录。 |

关闭插件时，仍可从本页打开模块说明、编辑 Markdown 和使用[通用模板](90-通用模板/README.md)。把整个 Vault 文件夹作为备份单位，保留其中的隐藏目录 `.obsidian`。

## 各平台注意事项

- **Windows** 用资源管理器“全部解压缩”，在解压后的文件夹中打开 Vault。文件名使用中文时，保留 ZIP 中的原名。
- **Ubuntu** 在文件管理器按 `Ctrl+H` 可显示 `.obsidian`。如果插件列表为空，先确认打开的是正确的文件夹，并检查解压后是否仍有 `.obsidian/plugins/`。
- **Android** 解压到 Obsidian 可访问的设备存储目录，例如 Documents。用能保留隐藏目录的解压工具，按系统提示授予存储权限。在命令面板打开 TBG Home，轻触时间块可编辑，从时间块上滑动可滚动时间轴。日记阅读模式可轻触标签，编辑模式可用“打开光标处的标签或来源链接”。[Obsidian Android 存储说明](https://obsidian.md/help/android)
- 时间工作台沿用 **Asia/Shanghai（UTC+08:00）**。跨时区使用时，按该时区核对和填写日程。今日日记取设备本地日期。
